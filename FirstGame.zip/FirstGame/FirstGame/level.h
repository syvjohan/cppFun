#ifndef LEVEL_H
#define LEVEL_H

#include "tinymath.h"

#endif // !LEVEL_H


//int level[WIDTH][HEIGHT] {
//1, 1, 1, 1, 1, 1, 1, 1, 1,
//1, 0, 0, 0, 0, 0, 0 , 0, 1
//// etc
//};
//
//enum BlockType {
// AIR = 0,
// STONE = 1,
//};

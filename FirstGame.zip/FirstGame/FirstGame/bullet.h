#ifndef BULLET_H
#define BULLET_H

//const int bulletSize = 10;
//rect bullets;
//const int bulletIntervall = 500;
//int lastBulletTime = 0;
//
//inline void bullet() {
//	
//}


#endif // !BULLET_H
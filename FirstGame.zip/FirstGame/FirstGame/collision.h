#ifndef COLLISION_H
#define COLLISION_H

#include "player.h"
#include "bullet.h"
#include "enemy.h"
#include "Defs.h"

void wallCollision();

#endif //"COLLISION_H